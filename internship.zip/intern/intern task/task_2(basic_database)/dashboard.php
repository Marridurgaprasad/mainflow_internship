<?php
// Include config file
require_once "config.php";

// Check if the user is logged in, if not then redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Authentication System</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container dashboard-container">
        <header class="dashboard-header">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <div class="user-info">
                <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                <a href="logout.php" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </header>
        
        <div class="dashboard-content">
            <div class="welcome-card">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h2>
                <p>You have successfully logged in to the secure area.</p>
                <p>Your email: <?php echo htmlspecialchars($_SESSION["email"]); ?></p>
            </div>
            
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-icon"><i class="fas fa-shield-alt"></i></div>
                    <div class="card-content">
                        <h3>Security</h3>
                        <p>Your account is protected with secure password hashing and session management.</p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon"><i class="fas fa-database"></i></div>
                    <div class="card-content">
                        <h3>Data Storage</h3>
                        <p>Your information is stored securely in our MySQL database with proper encryption.</p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon"><i class="fas fa-user-lock"></i></div>
                    <div class="card-content">
                        <h3>Privacy</h3>
                        <p>We respect your privacy and ensure your data is handled with care.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Authentication System. All rights reserved.</p>
    </footer>
</body>
</html>
