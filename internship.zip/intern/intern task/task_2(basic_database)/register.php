<?php
// Include config file
require_once "config.php";

// Check if the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Verify CSRF token
    if(!verifyCSRFToken($_POST["csrf_token"])) {
        $_SESSION["signup_err"] = "Security verification failed. Please try again.";
        header("location: index.php");
        exit;
    }
    
    // Validate username
    if(empty(trim($_POST["new-username"]))) {
        $_SESSION["signup_err"] = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["new-username"]))) {
        $_SESSION["signup_err"] = "Username can only contain letters, numbers, and underscores.";
    } else {
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = :username";
        
        if($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            
            // Set parameters
            $param_username = trim($_POST["new-username"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()) {
                if($stmt->rowCount() == 1) {
                    $_SESSION["signup_err"] = "This username is already taken.";
                }
            } else {
                $_SESSION["signup_err"] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }
    
    // Validate email
    if(empty(trim($_POST["email"]))) {
        $_SESSION["signup_err"] = "Please enter an email.";
    } elseif(!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
        $_SESSION["signup_err"] = "Invalid email format.";
    } else {
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE email = :email";
        
        if($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            
            // Set parameters
            $param_email = trim($_POST["email"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()) {
                if($stmt->rowCount() == 1) {
                    $_SESSION["signup_err"] = "This email is already registered.";
                }
            } else {
                $_SESSION["signup_err"] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["new-password"]))) {
        $_SESSION["signup_err"] = "Please enter a password.";     
    } elseif(strlen(trim($_POST["new-password"])) < 8) {
        $_SESSION["signup_err"] = "Password must have at least 8 characters.";
    } elseif(!preg_match('/[A-Z]/', trim($_POST["new-password"])) || 
             !preg_match('/[a-z]/', trim($_POST["new-password"])) || 
             !preg_match('/[0-9]/', trim($_POST["new-password"]))) {
        $_SESSION["signup_err"] = "Password must include at least one uppercase letter, one lowercase letter, and one number.";
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm-password"]))) {
        $_SESSION["signup_err"] = "Please confirm password.";     
    } else {
        $confirm_password = trim($_POST["confirm-password"]);
        if(empty($_SESSION["signup_err"]) && (trim($_POST["new-password"]) != $confirm_password)) {
            $_SESSION["signup_err"] = "Passwords did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($_SESSION["signup_err"])) {
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, email, password, created_at) VALUES (:username, :email, :password, NOW())";
         
        if($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
            
            // Set parameters
            $param_username = trim($_POST["new-username"]);
            $param_email = trim($_POST["email"]);
            $param_password = password_hash(trim($_POST["new-password"]), PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if($stmt->execute()) {
                // Redirect to login page with success message
                $_SESSION["signup_success"] = "Account created successfully! You can now log in.";
                header("location: index.php");
                exit;
            } else {
                $_SESSION["signup_err"] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }
    
    // Redirect back to signup form
    header("location: index.php");
    exit;
}
?>
