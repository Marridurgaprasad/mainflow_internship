<?php
// Include config file
require_once "config.php";

// Check if the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Verify CSRF token
    if(!verifyCSRFToken($_POST["csrf_token"])) {
        $_SESSION["login_err"] = "Security verification failed. Please try again.";
        header("location: index.php");
        exit;
    }
    
    // Define variables and initialize with empty values
    $username = $password = "";
    $username_err = $password_err = $login_err = "";
    
    // Validate username/email
    if(empty(trim($_POST["username"]))) {
        $username_err = "Please enter username or email.";
    } else {
        $username = trim($_POST["username"]);
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = "SELECT id, username, email, password FROM users WHERE username = :username OR email = :email";
        
        if($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            
            // Set parameters
            $param_username = $username;
            $param_email = $username;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()) {
                // Check if username exists, if yes then verify password
                if($stmt->rowCount() == 1) {
                    if($row = $stmt->fetch()) {
                        $id = $row["id"];
                        $username = $row["username"];
                        $email = $row["email"];
                        $hashed_password = $row["password"];
                        
                        if(password_verify($password, $hashed_password)) {
                            // Password is correct, start a new session
                            session_regenerate_id(true); // Prevent session fixation attacks
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                            $_SESSION["email"] = $email;
                            
                            // Log login time
                            $update_sql = "UPDATE users SET last_login = NOW() WHERE id = :id";
                            if($update_stmt = $pdo->prepare($update_sql)) {
                                $update_stmt->bindParam(":id", $id, PDO::PARAM_INT);
                                $update_stmt->execute();
                            }
                            
                            // Redirect user to dashboard
                            header("location: dashboard.php");
                            exit;
                        } else {
                            // Password is not valid
                            $_SESSION["login_err"] = "Invalid username or password.";
                        }
                    }
                } else {
                    // Username doesn't exist
                    $_SESSION["login_err"] = "Invalid username or password.";
                }
            } else {
                $_SESSION["login_err"] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    } else {
        if(!empty($username_err)) {
            $_SESSION["login_err"] = $username_err;
        } else {
            $_SESSION["login_err"] = $password_err;
        }
    }
    
    // Redirect back to login form
    header("location: index.php");
    exit;
}
?>
