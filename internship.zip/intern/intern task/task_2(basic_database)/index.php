<?php
// Include config file
require_once "config.php";

// Generate CSRF token
$csrf_token = generateCSRFToken();

// Check if user is already logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: dashboard.php");
    exit;
}

// Define variables and initialize with empty values
$login_err = "";
$signup_err = "";
$signup_success = "";

// Check if there are any error or success messages in session
if(isset($_SESSION["login_err"])) {
    $login_err = $_SESSION["login_err"];
    unset($_SESSION["login_err"]);
}

if(isset($_SESSION["signup_err"])) {
    $signup_err = $_SESSION["signup_err"];
    unset($_SESSION["signup_err"]);
}

if(isset($_SESSION["signup_success"])) {
    $signup_success = $_SESSION["signup_success"];
    unset($_SESSION["signup_success"]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Signup System</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-shield-alt"></i> Authentication System</h1>
            <p>Secure Login & Signup with PHP & MySQL</p>
        </header>

        <div class="forms-container">
            <!-- Login Form -->
            <div class="form-panel login-panel">
                <h2><i class="fas fa-sign-in-alt"></i> Login</h2>
                
                <?php if(!empty($login_err)): ?>
                    <div class="alert alert-danger"><?php echo $login_err; ?></div>
                <?php endif; ?>
                
                <form action="login.php" method="post" id="login-form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    
                    <div class="form-group">
                        <label for="username">Username or Email</label>
                        <input type="text" name="username" id="username" class="form-control" required>
                        <span class="error-message" id="username-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="password-field">
                            <input type="password" name="password" id="password" class="form-control" required>
                            <i class="fas fa-eye toggle-password" data-target="password"></i>
                        </div>
                        <span class="error-message" id="password-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                    
                    <p class="form-switch">Don't have an account? <a href="#" id="show-signup">Sign up</a></p>
                </form>
            </div>
            
            <!-- Signup Form -->
            <div class="form-panel signup-panel">
                <h2><i class="fas fa-user-plus"></i> Create Account</h2>
                
                <?php if(!empty($signup_err)): ?>
                    <div class="alert alert-danger"><?php echo $signup_err; ?></div>
                <?php endif; ?>
                
                <?php if(!empty($signup_success)): ?>
                    <div class="alert alert-success"><?php echo $signup_success; ?></div>
                <?php endif; ?>
                
                <form action="register.php" method="post" id="signup-form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    
                    <div class="form-group">
                        <label for="new-username">Username</label>
                        <input type="text" name="new-username" id="new-username" class="form-control" required>
                        <span class="error-message" id="new-username-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                        <span class="error-message" id="email-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="new-password">Password</label>
                        <div class="password-field">
                            <input type="password" name="new-password" id="new-password" class="form-control" required>
                            <i class="fas fa-eye toggle-password" data-target="new-password"></i>
                        </div>
                        <div class="password-strength">
                            <div class="strength-meter"></div>
                            <span class="strength-text">Password strength</span>
                        </div>
                        <span class="error-message" id="new-password-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm-password">Confirm Password</label>
                        <div class="password-field">
                            <input type="password" name="confirm-password" id="confirm-password" class="form-control" required>
                            <i class="fas fa-eye toggle-password" data-target="confirm-password"></i>
                        </div>
                        <span class="error-message" id="confirm-password-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Sign Up</button>
                    </div>
                    
                    <p class="form-switch">Already have an account? <a href="#" id="show-login">Login</a></p>
                </form>
            </div>
        </div>
    </div>
    
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Authentication System. All rights reserved.</p>
    </footer>
    
    <script src="js/script.js"></script>
</body>
</html>
