document.addEventListener("DOMContentLoaded", () => {
  // Form switching functionality
  const showSignupBtn = document.getElementById("show-signup")
  const showLoginBtn = document.getElementById("show-login")
  const loginPanel = document.querySelector(".login-panel")
  const signupPanel = document.querySelector(".signup-panel")

  if (showSignupBtn) {
    showSignupBtn.addEventListener("click", (e) => {
      e.preventDefault()
      loginPanel.classList.add("hide")
      signupPanel.classList.add("show")
    })
  }

  if (showLoginBtn) {
    showLoginBtn.addEventListener("click", (e) => {
      e.preventDefault()
      signupPanel.classList.remove("show")
      loginPanel.classList.remove("hide")
    })
  }

  // Password visibility toggle
  const togglePasswordBtns = document.querySelectorAll(".toggle-password")

  togglePasswordBtns.forEach((btn) => {
    btn.addEventListener("click", function () {
      const targetId = this.getAttribute("data-target")
      const passwordInput = document.getElementById(targetId)

      if (passwordInput.type === "password") {
        passwordInput.type = "text"
        this.classList.remove("fa-eye")
        this.classList.add("fa-eye-slash")
      } else {
        passwordInput.type = "password"
        this.classList.remove("fa-eye-slash")
        this.classList.add("fa-eye")
      }
    })
  })

  // Password strength meter
  const newPasswordInput = document.getElementById("new-password")
  const strengthMeter = document.querySelector(".strength-meter")
  const strengthText = document.querySelector(".strength-text")

  if (newPasswordInput) {
    newPasswordInput.addEventListener("input", function () {
      const password = this.value
      let strength = 0

      // Check password length
      if (password.length >= 8) {
        strength += 1
      }

      // Check for mixed case
      if (password.match(/[a-z]/) && password.match(/[A-Z]/)) {
        strength += 1
      }

      // Check for numbers
      if (password.match(/[0-9]/)) {
        strength += 1
      }

      // Check for special characters
      if (password.match(/[^a-zA-Z0-9]/)) {
        strength += 1
      }

      // Update strength meter
      strengthMeter.className = "strength-meter"

      if (password.length === 0) {
        strengthText.textContent = "Password strength"
      } else if (strength < 2) {
        strengthMeter.classList.add("weak")
        strengthText.textContent = "Weak password"
      } else if (strength < 4) {
        strengthMeter.classList.add("medium")
        strengthText.textContent = "Medium password"
      } else {
        strengthMeter.classList.add("strong")
        strengthText.textContent = "Strong password"
      }
    })
  }

  // Form validation
  const loginForm = document.getElementById("login-form")
  const signupForm = document.getElementById("signup-form")

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      const username = document.getElementById("username").value.trim()
      const password = document.getElementById("password").value.trim()
      let isValid = true

      // Reset error messages
      document.getElementById("username-error").textContent = ""
      document.getElementById("password-error").textContent = ""

      // Validate username
      if (username === "") {
        document.getElementById("username-error").textContent = "Please enter your username or email"
        isValid = false
      }

      // Validate password
      if (password === "") {
        document.getElementById("password-error").textContent = "Please enter your password"
        isValid = false
      }

      if (!isValid) {
        e.preventDefault()
      }
    })
  }

  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      const username = document.getElementById("new-username").value.trim()
      const email = document.getElementById("email").value.trim()
      const password = document.getElementById("new-password").value.trim()
      const confirmPassword = document.getElementById("confirm-password").value.trim()
      let isValid = true

      // Reset error messages
      document.getElementById("new-username-error").textContent = ""
      document.getElementById("email-error").textContent = ""
      document.getElementById("new-password-error").textContent = ""
      document.getElementById("confirm-password-error").textContent = ""

      // Validate username
      if (username === "") {
        document.getElementById("new-username-error").textContent = "Please enter a username"
        isValid = false
      } else if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        document.getElementById("new-username-error").textContent =
          "Username can only contain letters, numbers, and underscores"
        isValid = false
      }

      // Validate email
      if (email === "") {
        document.getElementById("email-error").textContent = "Please enter an email"
        isValid = false
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        document.getElementById("email-error").textContent = "Please enter a valid email address"
        isValid = false
      }

      // Validate password
      if (password === "") {
        document.getElementById("new-password-error").textContent = "Please enter a password"
        isValid = false
      } else if (password.length < 8) {
        document.getElementById("new-password-error").textContent = "Password must be at least 8 characters long"
        isValid = false
      } else if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password)) {
        document.getElementById("new-password-error").textContent =
          "Password must include at least one uppercase letter, one lowercase letter, and one number"
        isValid = false
      }

      // Validate confirm password
      if (confirmPassword === "") {
        document.getElementById("confirm-password-error").textContent = "Please confirm your password"
        isValid = false
      } else if (password !== confirmPassword) {
        document.getElementById("confirm-password-error").textContent = "Passwords do not match"
        isValid = false
      }

      if (!isValid) {
        e.preventDefault()
      }
    })
  }
})
